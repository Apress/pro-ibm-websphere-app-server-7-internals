package mywas7component;

public interface MyComponentInterface {
	
	public abstract void sayHello();

}
