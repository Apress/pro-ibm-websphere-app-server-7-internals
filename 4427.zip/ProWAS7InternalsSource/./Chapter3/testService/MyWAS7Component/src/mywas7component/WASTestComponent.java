package mywas7component;

import com.ibm.ws.runtime.component.ComponentImpl;

@SuppressWarnings("deprecation")
public class WASTestComponent extends ComponentImpl {

}
