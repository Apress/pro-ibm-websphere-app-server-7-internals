package mywas7component;

import com.ibm.ws.runtime.component.ContainerImpl;

public class myEJBLikeContainer extends ContainerImpl {

}
