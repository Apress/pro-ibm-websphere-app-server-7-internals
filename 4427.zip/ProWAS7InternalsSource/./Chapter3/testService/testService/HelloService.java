package testservice;

public interface HelloService {
	
	public void speak();
	
	public void yell();

}
