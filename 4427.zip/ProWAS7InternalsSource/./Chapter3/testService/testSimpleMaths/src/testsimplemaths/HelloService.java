package testsimplemaths;

public interface HelloService {
	
	public void speak();
	
	public void yell();

}
