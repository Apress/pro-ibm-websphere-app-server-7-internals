import com.ibm.ws.runtime.component.ComponentImpl;


public class myComponent extends ComponentImpl {

}
