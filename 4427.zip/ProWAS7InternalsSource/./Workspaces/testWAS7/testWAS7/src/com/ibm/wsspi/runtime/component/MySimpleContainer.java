package com.ibm.wsspi.runtime.component;

import com.ibm.ws.runtime.component.ContainerImpl;

public class MySimpleContainer extends ContainerImpl {

}
