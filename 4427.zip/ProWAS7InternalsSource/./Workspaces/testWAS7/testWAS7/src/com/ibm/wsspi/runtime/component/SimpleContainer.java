package com.ibm.wsspi.runtime.component;

import com.ibm.ws.container.Container;
import com.ibm.ws.runtime.component.ContainerImpl;

public class SimpleContainer extends ContainerImpl implements Container {

}
